package cl.ufro.dci.qrservice;

import java.util.Date;

public class Persona {
    private String rut;
    private String apellido;
    private String nombre;
    private String correo;
    private Date fechaNacimiento;
    private String comuna;

    public Persona(String rut, String apellido, String nombre, String correo, Date fechaNacimiento, String comuna) {
        this.rut = rut;
        this.apellido = apellido;
        this.nombre = nombre;
        this.correo = correo;
        this.fechaNacimiento = fechaNacimiento;
        this.comuna = comuna;
        ;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
}
