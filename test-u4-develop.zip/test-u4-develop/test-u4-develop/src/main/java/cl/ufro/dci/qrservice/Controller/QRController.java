package cl.ufro.dci.qrservice.Controller;

import cl.ufro.dci.qrservice.Services.QRGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.image.BufferedImage;

@RestController
@RequestMapping("/qrcode")
public class QRController {

    @PostMapping(value = "/generate", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<?> generateQRCode(@RequestBody String textMsg) throws Exception {
        // ------------------------------

        // you have to call your validate process here...

        //--------------------------------
        System.out.println("response: " + textMsg);
        return okResponse(QRGenerator.generateQRCodeImage(textMsg));
    }

    private ResponseEntity<BufferedImage> okResponse(BufferedImage image) {
        return new ResponseEntity<>(image, HttpStatus.OK);
    }
}